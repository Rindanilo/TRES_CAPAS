const $ = (id) => document.getElementById(id);
const form = $('formulario');
let productos = [];
const moneda = new Intl.NumberFormat('es-CO', {
style: 'currency', currency: 'COP', maximumFractionDigits: 0
});
async function api(ruta = '', metodo = 'GET', datos) {
const opciones = { method: metodo };
if (datos !== undefined) {
opciones.headers = { 'Content-Type': 'application/json' };
opciones.body = JSON.stringify(datos);
}
const respuesta = await fetch('/api/productos' + ruta, opciones);
const contenido = await respuesta.json();
if (!respuesta.ok) throw new Error(contenido.error || 'Error de API');
return contenido;
}
async function cargar() {
productos = await api();
$('filas').replaceChildren();
for (const p of productos) {
const fila = document.createElement('tr');
for (const valor of [p.nombre, moneda.format(p.precio), p.stock]) {
const celda = document.createElement('td');
celda.textContent = valor;
fila.append(celda);
}

const estado = p.stock < 5 ? 'Stock bajo' : 'Disponible';
const estadoCelda = document.createElement('td');
estadoCelda.textContent = estado;

if (p.stock < 5) {
  estadoCelda.classList.add('stock-bajo');
}

fila.append(estadoCelda);

const acciones = document.createElement('td');

for (const accion of ['Editar', 'Eliminar']) {
const boton = document.createElement('button');
boton.type = 'button';
boton.textContent = accion;
boton.dataset.id = p.id;
boton.dataset.accion = accion;
acciones.append(boton);
}
fila.append(acciones);
$('filas').append(fila);
}
}

async function ejecutar(tarea) {
$('mensaje').textContent = 'Procesando...';
document.querySelectorAll('button').forEach(b => b.disabled = true);
try {
await tarea();
$('mensaje').textContent = 'Operación completada.';
} catch (error) {
$('mensaje').textContent = error.message;
} finally {
document.querySelectorAll('button').forEach(b => b.disabled = false);
}
}
form.addEventListener('submit', (evento) => {
evento.preventDefault();
ejecutar(async () => {
const id = $('id').value;
const datos = {
nombre: $('nombre').value,
precio: Number($('precio').value),
stock: Number($('stock').value)
};
await api(id ? '/' + id : '', id ? 'PUT' : 'POST', datos);
form.reset();
$('id').value = '';
await cargar();
});
});
$('filas').addEventListener('click', (evento) => {
const boton = evento.target.closest('button');
if (!boton) return;
const p = productos.find(p => p.id === boton.dataset.id);
if (!p) return;
if (boton.dataset.accion === 'Editar') {
for (const campo of ['id', 'nombre', 'precio', 'stock']) {
$(campo).value = p[campo];
}
$('nombre').focus();
} else if (confirm('¿Eliminar ' + p.nombre + '?')) {
ejecutar(async () => {
await api('/' + p.id, 'DELETE');
form.reset();
$('id').value = '';
await cargar();
});
}
});
$('cancelar').addEventListener('click', () => {
form.reset();
$('id').value = '';
});
$('recargar').addEventListener('click', () => ejecutar(cargar));
ejecutar(cargar);
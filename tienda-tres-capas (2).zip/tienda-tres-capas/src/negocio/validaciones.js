export function fallo(mensaje, status = 400) {
return Object.assign(new Error(mensaje), { status });
}
export function validarId(id) {
const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
if (typeof id !== 'string' || !uuid.test(id)) {
throw fallo('El identificador no es válido.');
}
return id;
}
export function validarProducto(datos) {
if (!datos || typeof datos !== 'object' || Array.isArray(datos)) {
throw fallo('Envía un objeto con nombre, precio y stock.');
}
const nombre = typeof datos.nombre === 'string'
? datos.nombre.trim() : '';
const { precio, stock } = datos;
if (nombre.length < 2 || nombre.length > 60) {
throw fallo('El nombre debe tener entre 2 y 60 caracteres.');
}
if (!Number.isInteger(precio) || precio < 1 || precio > 1000000) {
throw fallo('Precio: entero entre 1 y 1000000 pesos.');
}
if (!Number.isInteger(stock) || stock < 0 || stock > 10000) {
throw fallo('Stock: entero entre 0 y 10000.');
}
// Solo estos campos pueden llegar al repositorio.
return { nombre, precio, stock };
}
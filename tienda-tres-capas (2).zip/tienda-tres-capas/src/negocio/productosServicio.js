import * as repo from '../datos/productosRepo.js';
import { fallo, validarId, validarProducto } from './validaciones.js';
export function listar() {
return repo.listar();
}
export function crear(datos) {
const producto = validarProducto(datos);
return repo.crear(producto);
}
export async function actualizar(id, datos) {
validarId(id);
const producto = validarProducto(datos);
const actualizado = await repo.actualizar(id, producto);
if (!actualizado) throw fallo('Producto no encontrado.', 404);
return actualizado;
}
export async function eliminar(id) {
validarId(id);
const eliminado = await repo.eliminar(id);
if (!eliminado) throw fallo('Producto no encontrado.', 404);
return eliminado;
}
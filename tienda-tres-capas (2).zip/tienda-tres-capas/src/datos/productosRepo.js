import { db } from './cliente.js';
function resultado({ data, error }) {
if (error) {
// No enviamos detalles de la conexión al navegador.
console.error('Error de datos:', error.code);
throw new Error('No fue posible consultar Supabase.');
}
return data;
}
export async function listar() {
return resultado(await db.from('productos')
.select('id,nombre,precio,stock').order('nombre'));
}
export async function crear(producto) {
return resultado(await db.from('productos')
.insert(producto).select('id,nombre,precio,stock').single());
}
export async function actualizar(id, producto) {
return resultado(await db.from('productos')
.update(producto).eq('id', id)
.select('id,nombre,precio,stock').maybeSingle());
}
export async function eliminar(id) {
return resultado(await db.from('productos')
.delete().eq('id', id).select('id').maybeSingle());
}
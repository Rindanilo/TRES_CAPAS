import { createClient } from '@supabase/supabase-js';
const url = process.env.SUPABASE_URL;
const clave = process.env.SUPABASE_SECRET_KEY;
if (!url || !clave || url.includes('TU-PROYECTO') ||
clave.includes('REEMPLAZAR')) {
throw new Error('Completa SUPABASE_URL y SUPABASE_SECRET_KEY en .env');
}
export const db = createClient(url, clave, {
auth: { persistSession: false, autoRefreshToken: false }
});
import express from 'express';
import { fileURLToPath } from 'node:url';
import * as servicio from './negocio/productosServicio.js';
const app = express();
app.use(express.json({ limit: '10kb' }));
const carpetaPublica = fileURLToPath(new URL('../public/', import.meta.url));
app.use(express.static(carpetaPublica));
app.get('/api/productos', async (req, res) => {
res.json(await servicio.listar());
});
app.post('/api/productos', async (req, res) => {
res.status(201).json(await servicio.crear(req.body));
});
app.put('/api/productos/:id', async (req, res) => {
res.json(await servicio.actualizar(req.params.id, req.body));
});
app.delete('/api/productos/:id', async (req, res) => {
res.json(await servicio.eliminar(req.params.id));
});
app.use('/api', (req, res) => {
res.status(404).json({ error: 'Ruta no encontrada.' });
});
app.use((error, req, res, next) => {
const status = [400, 404, 413].includes(error.status)
? error.status : 500;
const mensaje = status === 500 ? 'No se pudo completar la operación.'
: status === 400 && error.type === 'entity.parse.failed'
? 'El JSON no es válido.' : error.message;
res.status(status).json({ error: mensaje });
});
// Laboratorio individual: solo acepta conexiones de este equipo.
app.listen(3000, '127.0.0.1', () => {
console.log('Abre http://127.0.0.1:3000');
}); 

//uwu//